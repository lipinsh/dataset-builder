# Dataset Builder for Windows

## 🚀 Быстрый старт

1. **Установите Python** (если не установлен):
   - Скачайте с https://www.python.org/downloads/
   - При установке отметьте "Add Python to PATH"

2. **Установите зависимости**:
   - Дважды кликните на `install.bat`
   - Дождитесь завершения установки

3. **Запустите программу**:
   - Дважды кликните на `run.bat`
   - Или запустите: `python dataset_builder_advanced.py`

## 📋 Использование

1. Запустите программу
2. Введите путь к папке с Excel файлами (например: `C:\Data\2024`)
3. Дождитесь завершения обработки
4. Результат сохранится в файлы:
   - `combined_dataset.csv`
   - `combined_dataset.parquet`
   - `processing_statistics.csv`
   - `dataset_builder.log`

## 🔧 Сборка .exe файла

Для создания .exe файла выполните:

```cmd
pip install pyinstaller
pyinstaller --onefile --console --name=DatasetBuilderAdvanced dataset_builder_advanced.py
```

Готовый .exe файл будет в папке `dist/`

## 📞 Поддержка

- Изучите `README.md` для подробной документации
- Проверьте `INSTALLATION_GUIDE.md` для детальных инструкций
- Логи работы сохраняются в `dataset_builder.log`
